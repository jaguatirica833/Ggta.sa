package app.gtaportal.bridge

import android.app.Activity
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var box: LinearLayout

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val scroll = ScrollView(this)
        box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        scroll.addView(box)
        setContentView(scroll)
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)

        box.addView(TextView(this).apply { text = "GTA Portal Bridge"; textSize = 24f })
        status = TextView(this).apply { setPadding(0, 20, 0, 20) }
        box.addView(status)

        btn("1. Permitir sobreposição (botão flutuante)") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Permitir acesso ao uso (detectar Minecraft)") {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
        btn("3. Escolher pacote do GTA") { pickPackage() }
        btn("4. Iniciar Bridge") { startForegroundService(Intent(this, BridgeService::class.java)); toast("Bridge iniciado") }
        btn("Parar Bridge") { stopService(Intent(this, BridgeService::class.java)); toast("Bridge parado") }
        btn("Testar abertura do GTA") { GtaLauncher.open(this) }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun btn(label: String, onClick: () -> Unit) =
        box.addView(Button(this).apply { text = label; setOnClickListener { onClick() } })

    private fun toast(t: String) = Toast.makeText(this, t, Toast.LENGTH_SHORT).show()

    @Suppress("DEPRECATION")
    private fun usageOk(): Boolean {
        val ops = getSystemService(AppOpsManager::class.java)
        return ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun refresh() {
        val cfg = BridgeConfig.load(this)
        val pkg = GtaLauncher.resolvePackage(this, cfg)
        status.text = "Sobreposição: ${if (Settings.canDrawOverlays(this)) "OK" else "pendente"}\n" +
            "Acesso ao uso: ${if (usageOk()) "OK" else "pendente"}\n" +
            "Pacote do GTA: ${pkg ?: "não encontrado"}" +
            (if (cfg.gtaPackage.isBlank()) " (automático)" else " (manual)")
    }

    private fun pickPackage() {
        val cands = GtaLauncher.findCandidates(this)
        val items = cands.map { "${it.label}\n${it.pkg}" } + "Digitar pacote manualmente..."
        AlertDialog.Builder(this).setTitle("Pacote do GTA")
            .setItems(items.toTypedArray()) { _, i ->
                if (i < cands.size) save(cands[i].pkg) else manual()
            }.show()
    }

    private fun manual() {
        val et = EditText(this).apply { hint = "ex.: com.rockstargames.gtasa" }
        AlertDialog.Builder(this).setTitle("Pacote manual").setView(et)
            .setPositiveButton("Salvar") { _, _ -> save(et.text.toString().trim()) }.show()
    }

    private fun save(pkg: String) {
        val c = BridgeConfig.load(this); c.gtaPackage = pkg; c.save(this); refresh()
    }
}
