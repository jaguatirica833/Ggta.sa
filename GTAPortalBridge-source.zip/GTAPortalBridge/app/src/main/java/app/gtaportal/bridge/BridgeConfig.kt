package app.gtaportal.bridge

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persistido em <filesDir>/config.json */
data class BridgeConfig(
    var gtaPackage: String = "",          // "" = detectar automaticamente
    var autoOpen: Boolean = true,         // reservado (modo B); no modo A o toque é manual
    var overlayEnabled: Boolean = true,
    var minecraftPackages: List<String> = listOf("com.mojang.minecraftpe")
) {
    fun save(ctx: Context) {
        val o = JSONObject()
            .put("gta_package", gtaPackage)
            .put("auto_open", autoOpen)
            .put("overlay_enabled", overlayEnabled)
            .put("minecraft_packages", JSONArray(minecraftPackages))
        File(ctx.filesDir, "config.json").writeText(o.toString(2))
    }

    companion object {
        fun load(ctx: Context): BridgeConfig {
            val f = File(ctx.filesDir, "config.json")
            if (!f.exists()) return BridgeConfig()
            return try {
                val o = JSONObject(f.readText())
                val arr = o.optJSONArray("minecraft_packages")
                BridgeConfig(
                    o.optString("gta_package", ""),
                    o.optBoolean("auto_open", true),
                    o.optBoolean("overlay_enabled", true),
                    if (arr != null) List(arr.length()) { arr.getString(it) } else listOf("com.mojang.minecraftpe")
                )
            } catch (e: Exception) { BridgeConfig() }
        }
    }
}
