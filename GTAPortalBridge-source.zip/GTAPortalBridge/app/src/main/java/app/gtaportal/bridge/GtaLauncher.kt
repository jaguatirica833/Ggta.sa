package app.gtaportal.bridge

import android.content.Context
import android.content.Intent
import android.widget.Toast

object GtaLauncher {
    data class Candidate(val pkg: String, val label: String)

    /** Procura apps com ícone cujo nome/pacote sugerem GTA San Andreas. */
    fun findCandidates(ctx: Context): List<Candidate> {
        val pm = ctx.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return pm.queryIntentActivities(main, 0)
            .map { Candidate(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .filter {
                val s = "${it.pkg} ${it.label}".lowercase()
                "gta" in s || "san andreas" in s || "rockstar" in s
            }
            .distinctBy { it.pkg }
    }

    fun resolvePackage(ctx: Context, cfg: BridgeConfig = BridgeConfig.load(ctx)): String? =
        cfg.gtaPackage.ifBlank { findCandidates(ctx).firstOrNull()?.pkg }

    fun open(ctx: Context): Boolean {
        val pkg = resolvePackage(ctx)
        val intent = pkg?.let { ctx.packageManager.getLaunchIntentForPackage(it) }
        if (intent == null) {
            Toast.makeText(ctx, "GTA San Andreas não encontrado.", Toast.LENGTH_LONG).show()
            return false
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            ctx.startActivity(intent)
            Toast.makeText(ctx, "Abrindo GTA San Andreas...", Toast.LENGTH_SHORT).show()
            true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Não foi possível abrir: ${e.message}", Toast.LENGTH_LONG).show()
            false
        }
    }
}
