package app.gtaportal.bridge

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.*
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

/**
 * Enquanto o Minecraft está em primeiro plano, mostra um botão flutuante "GTA San Andreas".
 * Também detecta o retorno (GTA -> Minecraft) observando o app em primeiro plano.
 */
class BridgeService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var lastFg: String? = null
    private var cfg = BridgeConfig()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bridge", "Bridge", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bridge")
            .setContentTitle("GTA Portal Bridge ativo")
            .setContentText("Botão flutuante aparece sobre o Minecraft")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
        handler.post(tick)
    }

    private val tick = object : Runnable {
        override fun run() {
            cfg = BridgeConfig.load(this@BridgeService)
            foreground()?.let { onForeground(it) }
            handler.postDelayed(this, 1000)
        }
    }

    @Suppress("DEPRECATION")
    private fun foreground(): String? {
        val usm = getSystemService(UsageStatsManager::class.java)
        val now = System.currentTimeMillis()
        val events = usm.queryEvents(now - 60_000, now)
        val e = UsageEvents.Event()
        var pkg: String? = null
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) pkg = e.packageName
        }
        return pkg ?: lastFg // sem eventos novos: mantém o último conhecido
    }

    private fun onForeground(fg: String) {
        val inMinecraft = fg in cfg.minecraftPackages
        if (inMinecraft && cfg.overlayEnabled) showOverlay() else hideOverlay()
        if (fg != lastFg) {
            if (inMinecraft && lastFg != null && lastFg == GtaLauncher.resolvePackage(this, cfg)) {
                Toast.makeText(this, "Bem-vindo de volta ao Minecraft!", Toast.LENGTH_SHORT).show()
            }
            lastFg = fg
        }
    }

    private fun showOverlay() {
        if (overlay != null || !Settings.canDrawOverlays(this)) return
        val b = Button(this).apply {
            text = "🌀 GTA San Andreas"
            setOnClickListener { GtaLauncher.open(this@BridgeService) }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 24; y = 160 }
        getSystemService(WindowManager::class.java).addView(b, lp)
        overlay = b
    }

    private fun hideOverlay() {
        overlay?.let { runCatching { getSystemService(WindowManager::class.java).removeView(it) } }
        overlay = null
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int) = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        hideOverlay()
        super.onDestroy()
    }
}
